# Devtern-task-2
Developed an enticing product landing page with HTML and CSS
